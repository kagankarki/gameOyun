export default function Loader({ label = 'Yükleniyor…' }: { label?: string }) {
  return (
    <div className="grid min-h-[60vh] place-items-center">
      <div className="scene">
        <div className="preserve-3d relative h-20 w-20 animate-[spin_2.6s_linear_infinite]">
          {[
            'rotateY(0deg) translateZ(40px)',
            'rotateY(90deg) translateZ(40px)',
            'rotateY(180deg) translateZ(40px)',
            'rotateY(270deg) translateZ(40px)',
            'rotateX(90deg) translateZ(40px)',
            'rotateX(-90deg) translateZ(40px)',
          ].map((t, i) => (
            <div
              key={i}
              className="absolute inset-0 rounded-lg border border-indigo-300/40 bg-indigo-500/15 backdrop-blur-sm"
              style={{ transform: t }}
            />
          ))}
        </div>
        <p className="mt-8 text-center text-sm font-medium text-indigo-200/80">{label}</p>
      </div>
    </div>
  )
}
