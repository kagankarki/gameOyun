import { createContext, useCallback, useContext, useState, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { uid } from '@/lib/utils'

type Kind = 'success' | 'error' | 'info'
interface Item {
  id: string
  kind: Kind
  text: string
}

const Ctx = createContext<{ push: (text: string, kind?: Kind) => void } | null>(null)

const styles: Record<Kind, string> = {
  success: 'border-emerald-400/40 bg-emerald-500/15 text-emerald-100',
  error: 'border-rose-400/40 bg-rose-500/15 text-rose-100',
  info: 'border-indigo-400/40 bg-indigo-500/15 text-indigo-100',
}
const icons: Record<Kind, string> = { success: '✓', error: '!', info: 'i' }

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>([])

  const push = useCallback((text: string, kind: Kind = 'info') => {
    const id = uid('t')
    setItems((s) => [...s, { id, kind, text }])
    setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), 3800)
  }, [])

  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-6 right-6 z-[100] flex w-[min(92vw,380px)] flex-col gap-3">
        <AnimatePresence>
          {items.map((i) => (
            <motion.div
              key={i.id}
              initial={{ opacity: 0, y: 24, rotateX: -35, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
              exit={{ opacity: 0, x: 40, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
              className={`pointer-events-auto flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm backdrop-blur-xl shadow-card3d ${styles[i.kind]}`}
            >
              <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-white/15 text-xs font-bold">
                {icons[i.kind]}
              </span>
              <p className="leading-snug">{i.text}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  )
}

export const useToast = () => {
  const c = useContext(Ctx)
  if (!c) throw new Error('useToast, ToastProvider içinde kullanılmalı')
  return c.push
}
