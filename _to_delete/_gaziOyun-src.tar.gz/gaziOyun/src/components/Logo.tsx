export default function Logo({ size = 44 }: { size?: number }) {
  return (
    <div
      className="relative grid place-items-center rounded-2xl"
      style={{ width: size, height: size }}
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-indigo-400 via-indigo-600 to-cyan-400 opacity-90 blur-[1px]" />
      <div className="absolute inset-[2px] rounded-[14px] bg-ink-900/85 backdrop-blur" />
      <svg
        viewBox="0 0 48 48"
        width={size * 0.62}
        height={size * 0.62}
        className="relative z-10"
        aria-hidden
      >
        <defs>
          <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#a5b4fc" />
            <stop offset="55%" stopColor="#818cf8" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
        {/* büyüteç + ünlem: "hatayı yakala" */}
        <circle cx="20" cy="20" r="12" fill="none" stroke="url(#lg)" strokeWidth="3.4" />
        <path d="M29 29 L41 41" stroke="url(#lg)" strokeWidth="4.2" strokeLinecap="round" />
        <path d="M20 13 v9" stroke="#fbbf24" strokeWidth="3.4" strokeLinecap="round" />
        <circle cx="20" cy="26.6" r="1.9" fill="#fbbf24" />
      </svg>
    </div>
  )
}
