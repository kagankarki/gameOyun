import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import Loader from '@/components/Loader'
import { useToast } from '@/components/Toast'
import * as api from '@/lib/api'
import type { Block, Lesson } from '@/lib/types'
import { cx, uid } from '@/lib/utils'

const field =
  'w-full rounded-2xl border border-white/12 bg-white/[0.05] px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-all focus:border-indigo-400/60 focus:bg-white/[0.08] focus:ring-4 focus:ring-indigo-500/15'

/** Yapıştırılan ders notunu anlamlı bloklara böler. */
function splitNote(raw: string): string[] {
  const byLine = raw
    .split(/\r?\n+/)
    .map((s) => s.trim())
    .filter(Boolean)

  // Tek satırlık uzun metin geldiyse cümlelere böl
  if (byLine.length <= 1) {
    return raw
      .split(/(?<=[.!?…])\s+(?=[A-ZÇĞİÖŞÜ0-9])/)
      .map((s) => s.trim())
      .filter((s) => s.length > 1)
  }

  return byLine.map((l) => l.replace(/^([-•*–]|\d+[.)])\s*/, '').trim()).filter(Boolean)
}

export default function LessonEditor() {
  const { id } = useParams()
  const nav = useNavigate()
  const toast = useToast()

  const [lesson, setLesson] = useState<Lesson | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [bulk, setBulk] = useState('')
  const [showBulk, setShowBulk] = useState(false)
  const dirty = useRef(false)

  useEffect(() => {
    let alive = true
    api.getLesson(id!).then((l) => {
      if (!alive) return
      setLesson(l)
      setLoading(false)
    })
    return () => {
      alive = false
    }
  }, [id])

  const patch = (p: Partial<Lesson>) => {
    dirty.current = true
    setLesson((l) => (l ? { ...l, ...p } : l))
  }

  const patchBlock = (bid: string, p: Partial<Block>) => {
    dirty.current = true
    setLesson((l) =>
      l ? { ...l, blocks: l.blocks.map((b) => (b.id === bid ? { ...b, ...p } : b)) } : l,
    )
  }

  const addBlock = () => {
    dirty.current = true
    setLesson((l) =>
      l
        ? { ...l, blocks: [...l.blocks, { id: uid('b'), text: '', isWrong: false, points: 100 }] }
        : l,
    )
  }

  const removeBlock = (bid: string) => {
    dirty.current = true
    setLesson((l) => (l ? { ...l, blocks: l.blocks.filter((b) => b.id !== bid) } : l))
  }

  const move = (index: number, dir: -1 | 1) => {
    setLesson((l) => {
      if (!l) return l
      const next = [...l.blocks]
      const j = index + dir
      if (j < 0 || j >= next.length) return l
      ;[next[index], next[j]] = [next[j], next[index]]
      dirty.current = true
      return { ...l, blocks: next }
    })
  }

  const importBulk = () => {
    const parts = splitNote(bulk)
    if (!parts.length) return toast('Metin boş görünüyor.', 'error')
    dirty.current = true
    setLesson((l) =>
      l
        ? {
            ...l,
            blocks: [
              ...l.blocks,
              ...parts.map((t) => ({ id: uid('b'), text: t, isWrong: false, points: 100 })),
            ],
          }
        : l,
    )
    setBulk('')
    setShowBulk(false)
    toast(`${parts.length} blok eklendi. Şimdi hatalı olanları işaretle.`, 'success')
  }

  const save = async (publish?: boolean) => {
    if (!lesson) return
    const cleaned = lesson.blocks.filter((b) => b.text.trim())
    const traps = cleaned.filter((b) => b.isWrong)

    if (!lesson.title.trim()) return toast('Ders başlığı boş olamaz.', 'error')
    if (publish && cleaned.length < 2) return toast('En az 2 blok gerekli.', 'error')
    if (publish && traps.length === 0)
      return toast('Yayına almadan önce en az bir hatalı blok işaretle.', 'error')
    if (traps.some((b) => !b.correction?.trim()))
      return toast('İşaretlediğin her hata için “doğrusu” alanını doldur.', 'error')

    setSaving(true)
    try {
      const next = { ...lesson, blocks: cleaned, isLive: publish ?? lesson.isLive }
      await api.saveLesson(next)
      setLesson(next)
      dirty.current = false
      toast(publish ? 'Ders yayına alındı! 🚀' : 'Kaydedildi.', 'success')
      if (publish) nav('/hoca')
    } catch (e) {
      toast('Kaydedilemedi: ' + (e as Error).message, 'error')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Loader label="Ders yükleniyor…" />
  if (!lesson)
    return (
      <div className="grid min-h-[60vh] place-items-center px-6 text-center">
        <div>
          <p className="text-5xl">🕳️</p>
          <h2 className="mt-4 font-display text-2xl font-bold">Ders bulunamadı</h2>
          <div className="mt-6">
            <Button3D onClick={() => nav('/hoca')}>Panele Dön</Button3D>
          </div>
        </div>
      </div>
    )

  const traps = lesson.blocks.filter((b) => b.isWrong).length

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="mx-auto max-w-5xl px-5 py-12 sm:px-6"
    >
      <button
        onClick={() => nav('/hoca')}
        className="mb-6 text-sm text-slate-400 transition-colors hover:text-white"
      >
        ← Panele dön
      </button>

      {/* ── Ders bilgileri ── */}
      <div className="glass mb-8 p-7">
        <h1 className="mb-6 font-display text-2xl font-bold tracking-tight">Ders Bilgileri</h1>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="sm:col-span-2">
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Başlık
            </label>
            <input
              className={field}
              value={lesson.title}
              onChange={(e) => patch({ title: e.target.value })}
              placeholder="Örn. Üst Ekstremite Kemikleri"
            />
          </div>
          <div>
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Ders / Konu
            </label>
            <input
              className={field}
              value={lesson.subject}
              onChange={(e) => patch({ subject: e.target.value })}
              placeholder="Anatomi"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-400">
              Açıklama / öğrenciye yönerge
            </label>
            <textarea
              className={cx(field, 'min-h-[84px] resize-y')}
              value={lesson.description}
              onChange={(e) => patch({ description: e.target.value })}
              placeholder="Bu derste 4 kasıtlı hata var, hepsini yakala!"
            />
          </div>
        </div>
      </div>

      {/* ── Blok araç çubuğu ── */}
      <div className="glass sticky top-[78px] z-30 mb-6 flex flex-wrap items-center gap-3 p-4">
        <div className="flex items-center gap-2 text-sm">
          <span className="rounded-lg bg-white/8 px-2.5 py-1 font-semibold text-slate-200">
            {lesson.blocks.length} blok
          </span>
          <span
            className={cx(
              'rounded-lg px-2.5 py-1 font-semibold',
              traps > 0
                ? 'bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30'
                : 'bg-white/5 text-slate-400',
            )}
          >
            {traps} tuzak
          </span>
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          <Button3D size="sm" tone="ghost" onClick={() => setShowBulk((s) => !s)} icon="📋">
            Notu Yapıştır
          </Button3D>
          <Button3D size="sm" tone="ghost" onClick={addBlock} icon="＋">
            Blok Ekle
          </Button3D>
          <Button3D size="sm" onClick={() => save()} disabled={saving}>
            {saving ? 'Kaydediliyor…' : 'Kaydet'}
          </Button3D>
          <Button3D size="sm" tone="success" onClick={() => save(true)} disabled={saving}>
            Yayına Al
          </Button3D>
        </div>
      </div>

      {/* ── Toplu içe aktarma ── */}
      <AnimatePresence>
        {showBulk && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="glass mb-6 p-6">
              <h3 className="font-display text-lg font-semibold">Ders notunu yapıştır</h3>
              <p className="mt-1.5 text-sm text-slate-400">
                Her satır ayrı bir blok olur. Tek paragraf yapıştırırsan cümlelere bölünür.
                Sonrasında hangi blokların yanlış olduğunu işaretlersin.
              </p>
              <textarea
                className={cx(field, 'mt-4 min-h-[200px] resize-y font-mono text-[13px]')}
                value={bulk}
                onChange={(e) => setBulk(e.target.value)}
                placeholder={'Omuz kuşağını clavicula ve scapula oluşturur.\nHumerus kolun tek kemiğidir.\n…'}
              />
              <div className="mt-4 flex gap-2">
                <Button3D size="sm" onClick={importBulk}>
                  Bloklara Dönüştür
                </Button3D>
                <Button3D size="sm" tone="ghost" onClick={() => setShowBulk(false)}>
                  Vazgeç
                </Button3D>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Bloklar ── */}
      {lesson.blocks.length === 0 ? (
        <div className="glass grid place-items-center p-14 text-center">
          <p className="text-4xl">✍️</p>
          <h3 className="mt-4 font-display text-lg font-semibold">Ders notu boş</h3>
          <p className="mt-2 max-w-md text-sm text-slate-400">
            “Notu Yapıştır” ile hazır metnini aktar ya da tek tek blok ekle.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence initial={false}>
            {lesson.blocks.map((b, i) => (
              <motion.div
                key={b.id}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.25 }}
                className={cx(
                  'rounded-3xl border p-5 backdrop-blur-xl transition-colors duration-300',
                  b.isWrong
                    ? 'border-rose-400/40 bg-rose-500/[0.08] shadow-[0_0_0_1px_rgba(251,113,133,.15),0_20px_40px_-24px_rgba(244,63,94,.6)]'
                    : 'border-white/10 bg-white/[0.045]',
                )}
              >
                <div className="mb-3 flex items-center gap-3">
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-white/8 font-mono text-xs font-bold text-slate-300">
                    {i + 1}
                  </span>

                  <label className="flex cursor-pointer select-none items-center gap-2.5">
                    <span className="relative inline-flex">
                      <input
                        type="checkbox"
                        className="peer sr-only"
                        checked={b.isWrong}
                        onChange={(e) =>
                          patchBlock(b.id, {
                            isWrong: e.target.checked,
                            points: b.points ?? 100,
                          })
                        }
                      />
                      <span className="h-6 w-11 rounded-full bg-white/12 transition-colors peer-checked:bg-rose-500" />
                      <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
                    </span>
                    <span
                      className={cx(
                        'text-sm font-semibold transition-colors',
                        b.isWrong ? 'text-rose-300' : 'text-slate-400',
                      )}
                    >
                      {b.isWrong ? 'Bu blokta HATA var' : 'Bilgi doğru'}
                    </span>
                  </label>

                  <div className="ml-auto flex items-center gap-1">
                    <button
                      onClick={() => move(i, -1)}
                      className="rounded-lg px-2 py-1 text-slate-500 hover:bg-white/8 hover:text-white"
                      title="Yukarı taşı"
                    >
                      ↑
                    </button>
                    <button
                      onClick={() => move(i, 1)}
                      className="rounded-lg px-2 py-1 text-slate-500 hover:bg-white/8 hover:text-white"
                      title="Aşağı taşı"
                    >
                      ↓
                    </button>
                    <button
                      onClick={() => removeBlock(b.id)}
                      className="rounded-lg px-2 py-1 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300"
                      title="Bloğu sil"
                    >
                      ✕
                    </button>
                  </div>
                </div>

                <textarea
                  className={cx(field, 'min-h-[76px] resize-y leading-relaxed')}
                  value={b.text}
                  onChange={(e) => patchBlock(b.id, { text: e.target.value })}
                  placeholder="Ders notunun bu bölümü…"
                />

                <AnimatePresence>
                  {b.isWrong && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_130px]">
                        <div>
                          <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-emerald-300/80">
                            Doğrusu / açıklama (öğrenciye gösterilir)
                          </label>
                          <textarea
                            className={cx(
                              field,
                              'min-h-[62px] resize-y border-emerald-400/25 bg-emerald-400/[0.06]',
                            )}
                            value={b.correction ?? ''}
                            onChange={(e) => patchBlock(b.id, { correction: e.target.value })}
                            placeholder="Doğrusu şudur çünkü…"
                          />
                        </div>
                        <div>
                          <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-amber-300/80">
                            Puan
                          </label>
                          <input
                            type="number"
                            min={10}
                            max={500}
                            step={10}
                            className={cx(field, 'border-amber-400/25 bg-amber-400/[0.06]')}
                            value={b.points ?? 100}
                            onChange={(e) =>
                              patchBlock(b.id, { points: Number(e.target.value) || 100 })
                            }
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>

          <div className="flex justify-center pt-2">
            <Button3D tone="ghost" onClick={addBlock} icon="＋">
              Blok Ekle
            </Button3D>
          </div>
        </div>
      )}
    </motion.div>
  )
}
