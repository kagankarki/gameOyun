import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { cx } from '@/lib/utils'

type Tone = 'primary' | 'danger' | 'ghost' | 'success' | 'gold'

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode
  tone?: Tone
  size?: 'sm' | 'md' | 'lg' | 'xl'
  icon?: ReactNode
  full?: boolean
}

const tones: Record<Tone, { face: string; edge: string; ring: string }> = {
  primary: {
    face: 'bg-gradient-to-b from-indigo-400 via-indigo-500 to-indigo-600 text-white',
    edge: 'rgb(49 46 129)',
    ring: 'rgba(99,102,241,.45)',
  },
  danger: {
    face: 'bg-gradient-to-b from-rose-400 via-rose-500 to-rose-600 text-white',
    edge: 'rgb(136 19 55)',
    ring: 'rgba(244,63,94,.45)',
  },
  success: {
    face: 'bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 text-white',
    edge: 'rgb(6 78 59)',
    ring: 'rgba(16,185,129,.45)',
  },
  gold: {
    face: 'bg-gradient-to-b from-amber-300 via-amber-400 to-amber-500 text-amber-950',
    edge: 'rgb(120 53 15)',
    ring: 'rgba(251,191,36,.45)',
  },
  ghost: {
    face: 'bg-white/10 text-slate-100 backdrop-blur-md',
    edge: 'rgba(255,255,255,.14)',
    ring: 'rgba(255,255,255,.18)',
  },
}

const sizes = {
  sm: 'px-3.5 py-2 text-xs rounded-xl',
  md: 'px-5 py-2.5 text-sm rounded-2xl',
  lg: 'px-7 py-3.5 text-base rounded-2xl',
  xl: 'px-9 py-4 text-lg rounded-3xl',
}

/** Gerçekten basılan hissi veren, kenar derinliği olan 3B buton. */
export default function Button3D({
  children,
  tone = 'primary',
  size = 'md',
  icon,
  full,
  className,
  disabled,
  ...rest
}: Props) {
  const t = tones[tone]
  return (
    <button
      {...rest}
      disabled={disabled}
      className={cx(
        'group relative inline-flex select-none items-center justify-center gap-2 font-display font-semibold tracking-tight',
        'border border-white/15 transition-all duration-150 will-change-transform',
        'hover:-translate-y-[2px] active:translate-y-[5px] disabled:pointer-events-none disabled:opacity-45',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60 focus-visible:ring-offset-2 focus-visible:ring-offset-ink-900',
        sizes[size],
        t.face,
        full && 'w-full',
        className,
      )}
      style={{
        boxShadow: `inset 0 1px 0 rgba(255,255,255,.28), 0 6px 0 0 ${t.edge}, 0 14px 26px -8px ${t.ring}`,
      }}
    >
      {icon && <span className="shrink-0 text-[1.1em] leading-none">{icon}</span>}
      <span className="relative z-10">{children}</span>
      <span className="pointer-events-none absolute inset-x-2 top-0 h-1/2 rounded-t-2xl bg-gradient-to-b from-white/25 to-transparent opacity-70" />
    </button>
  )
}
