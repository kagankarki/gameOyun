# 🎯 Hatayı Yakala

**Gazi Üniversitesi × Prof. Dr. Tuncay Peker** — interaktif ders platformu.

Hoca derste bilinçli olarak yanlış bilgiler verir; öğrenci hatayı fark ettiği anda
**“Burada Yanlış Var!”** butonuna basar. Doğru yakalarsa puan alır, boşa basarsa ceza yer.

---

## ⚡ Hızlı Başlangıç

```bash
npm install
npm run dev
```

Tarayıcı otomatik açılır → `http://localhost:5173`

> **Firebase kurmadan da çalışır.** `.env` dosyası yoksa uygulama **DEMO MOD**’a düşer ve
> tüm verileri tarayıcının `localStorage`’ında tutar. Böylece hiçbir kurulum yapmadan
> her şeyi deneyebilirsin.

### İlk deneme için

1. `npm run dev`
2. **Kayıt Ol → Öğretim Üyesi** seç, kod olarak `gazi2026` gir.
3. **Yeni Ders Oluştur** → “Notu Yapıştır” ile ders notunu aktar → hatalı blokları işaretle → **Yayına Al**.
4. Yeni bir sekmede (veya gizli pencerede) **Öğrenci** olarak kayıt ol ve derse gir.

Sistemde hazır bir **örnek ders** (Anatomi — Üst Ekstremite Kemikleri, 4 gizli hata) zaten yayında.

---

## 🔥 Firebase’e Bağlama

1. [Firebase Console](https://console.firebase.google.com)’da yeni proje aç.
2. **Authentication → Sign-in method → E-posta/Şifre**’yi etkinleştir.
3. **Firestore Database** oluştur (production mode).
4. **Proje Ayarları → Genel → Web uygulaması ekle** ve çıkan config değerlerini kopyala.
5. Proje kökünde `.env.example` dosyasını `.env` olarak kopyala ve değerleri yapıştır:

```env
VITE_FIREBASE_API_KEY=AIza...
VITE_FIREBASE_AUTH_DOMAIN=projen.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=projen
VITE_FIREBASE_STORAGE_BUCKET=projen.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=1234567890
VITE_FIREBASE_APP_ID=1:1234:web:abcd
VITE_TEACHER_CODE=gazi2026
```

6. `firestore.rules` dosyasının içeriğini **Firestore → Kurallar** sekmesine yapıştır ve yayınla.
7. `npm run dev` — sağ üstteki “DEMO MOD” rozeti kaybolduysa canlı moddasın.

### Firestore koleksiyonları

| Koleksiyon | Açıklama |
|---|---|
| `users` | `{ uid, name, email, role: 'teacher' \| 'student', createdAt }` |
| `lessons` | `{ id, title, subject, description, teacherId, teacherName, blocks[], isLive, ... }` |
| `attempts` | `{ id, lessonId, studentId, flagged[], correct, missed, falseAlarm, score, ... }` |

`blocks[]` içindeki her eleman: `{ id, text, isWrong, correction?, points? }`

---

## 🧠 Puanlama

| Durum | Etki |
|---|---|
| Hatalı bloğa bastı (**yakaladı**) | `+ blok puanı` (varsayılan 100) |
| Doğru bloğa bastı (**boşa basma**) | `− 40` |
| Hatalı bloğu kaçırdı | `0` + “kaçırdın” uyarısı |

Toplam puan hiçbir zaman 0’ın altına düşmez. Sıralama tüm derslerin toplamına göre hesaplanır.

Klavye kısayolları: `Boşluk` = yanlış bildir · `Enter` / `→` = devam.

---

## 🎨 3D Arayüz

- **WebGL sahne** (`src/components/Scene3D.tsx`) — three.js + react-three-fiber ile
  bozunan çekirdek, yüzen kristaller, parıltılar ve fareyi takip eden kamera.
- **TiltCard** — fareye göre gerçek perspektifle eğilen, içeriği `translateZ` ile
  yüzeyden kaldırılmış kartlar.
- **Button3D** — kenar derinliği olan, basınca gerçekten çöken butonlar.
- **Ders akışı** — her blok 3B döner geçişle sahneye girer.
- WebGL desteklenmeyen cihazlarda otomatik olarak CSS arka planına düşer (`SceneBoundary`).

---

## 📁 Klasör Yapısı

```
src/
├── components/     Scene3D, TiltCard, Button3D, Navbar, Toast, Loader, Logo
├── context/        AuthContext — oturum yönetimi
├── lib/
│   ├── api.ts      Tüm veri işlemleri (Firebase ↔ demo mod otomatik seçimi)
│   ├── firebase.ts Firebase başlatma
│   ├── store.ts    Demo mod deposu (localStorage)
│   ├── seed.ts     Örnek ders
│   ├── types.ts    Tip tanımları
│   └── utils.ts    Yardımcılar
└── pages/
    ├── Landing.tsx           Tanıtım sayfası
    ├── Login.tsx             Giriş / kayıt (rol seçimli)
    ├── TeacherDashboard.tsx  Hoca paneli
    ├── LessonEditor.tsx      Ders notu + hata işaretleme
    ├── LiveResults.tsx       Blok bazlı canlı analiz
    ├── StudentLessons.tsx    Öğrenci ders listesi
    ├── LessonPlay.tsx        Oyun ekranı
    └── Leaderboard.tsx       Sıralama + podyum
```

---

## 📦 Komutlar

| Komut | Ne yapar |
|---|---|
| `npm run dev` | Geliştirme sunucusu |
| `npm run build` | `dist/` klasörüne üretim derlemesi |
| `npm run preview` | Derlemeyi yerelde önizle |
| `npm run typecheck` | TypeScript kontrolü |

---

## 🚀 Yayına Alma

```bash
npm run build
```

`dist/` klasörünü Firebase Hosting, Vercel veya Netlify’a yükle.
SPA olduğu için sunucuda **tüm yolları `index.html`’e yönlendirmeyi** unutma.

Firebase Hosting için:

```bash
npm i -g firebase-tools
firebase login
firebase init hosting     # public dizin: dist, SPA: Yes
npm run build && firebase deploy
```
