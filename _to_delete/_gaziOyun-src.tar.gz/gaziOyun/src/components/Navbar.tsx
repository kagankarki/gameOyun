import { Link, NavLink, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Logo from './Logo'
import Button3D from './Button3D'
import { useAuth } from '@/context/AuthContext'
import { isFirebaseConfigured } from '@/lib/api'
import { cx, initials } from '@/lib/utils'

export default function Navbar() {
  const { user, signOut, isTeacher } = useAuth()
  const nav = useNavigate()

  const links = user
    ? isTeacher
      ? [
          { to: '/hoca', label: 'Panelim' },
          { to: '/siralama', label: 'Sıralama' },
        ]
      : [
          { to: '/dersler', label: 'Dersler' },
          { to: '/siralama', label: 'Sıralama' },
        ]
    : []

  return (
    <motion.header
      initial={{ y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 150, damping: 20 }}
      className="sticky top-0 z-50 border-b border-white/10 bg-ink-900/55 backdrop-blur-xl"
    >
      <div className="mx-auto flex h-[70px] max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link to="/" className="group flex items-center gap-3">
          <div className="transition-transform duration-300 group-hover:rotate-[8deg] group-hover:scale-105">
            <Logo size={40} />
          </div>
          <div className="leading-none">
            <p className="font-display text-[15px] font-bold tracking-tight text-white">
              Hatayı Yakala
            </p>
            <p className="mt-1 text-[10px] uppercase tracking-[0.18em] text-indigo-300/80">
              Gazi Üniversitesi
            </p>
          </div>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                cx(
                  'rounded-xl px-3.5 py-2 text-sm font-medium transition-all',
                  isActive
                    ? 'bg-white/10 text-white ring-1 ring-white/15'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white',
                )
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          {!isFirebaseConfigured && (
            <span
              title="Firebase bilgileri girilmediği için veriler tarayıcıda tutuluyor."
              className="hidden rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-[11px] font-semibold text-amber-200 sm:inline-block"
            >
              DEMO MOD
            </span>
          )}

          {user ? (
            <>
              <div className="hidden items-center gap-2.5 rounded-2xl border border-white/10 bg-white/5 py-1.5 pl-1.5 pr-3.5 sm:flex">
                <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-indigo-400 to-cyan-400 text-xs font-bold text-ink-900">
                  {initials(user.name)}
                </div>
                <div className="leading-tight">
                  <p className="text-xs font-semibold text-white">{user.name}</p>
                  <p className="text-[10px] uppercase tracking-wider text-indigo-300/80">
                    {isTeacher ? 'Öğretim Üyesi' : 'Öğrenci'}
                  </p>
                </div>
              </div>
              <Button3D
                tone="ghost"
                size="sm"
                onClick={async () => {
                  await signOut()
                  nav('/')
                }}
              >
                Çıkış
              </Button3D>
            </>
          ) : (
            <Button3D size="sm" onClick={() => nav('/giris')}>
              Giriş Yap
            </Button3D>
          )}
        </div>
      </div>
    </motion.header>
  )
}
