/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Gazi Üniversitesi lacivert + neon aksanlar
        gazi: {
          50: '#eef2ff',
          100: '#e0e7ff',
          300: '#a5b4fc',
          400: '#818cf8',
          500: '#6366f1',
          600: '#4f46e5',
          700: '#4338ca',
          800: '#2b2f77',
          900: '#151a4a',
          950: '#0a0d2b',
        },
        ink: {
          900: '#05060f',
          800: '#0a0c1c',
          700: '#111429',
        },
        neon: {
          cyan: '#22d3ee',
          violet: '#a78bfa',
          gold: '#fbbf24',
          rose: '#fb7185',
          lime: '#a3e635',
        },
      },
      boxShadow: {
        card3d: '0 30px 60px -12px rgba(0,0,0,.7), 0 18px 36px -18px rgba(99,102,241,.55)',
        neon: '0 0 0 1px rgba(129,140,248,.35), 0 0 30px rgba(99,102,241,.35)',
        press: 'inset 0 1px 0 rgba(255,255,255,.18), 0 8px 0 0 rgba(49,46,129,.9), 0 16px 30px rgba(0,0,0,.55)',
        pressRed: 'inset 0 1px 0 rgba(255,255,255,.2), 0 8px 0 0 rgba(136,19,55,.95), 0 16px 34px rgba(190,18,60,.4)',
      },
      keyframes: {
        float: {
          '0%,100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-14px)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        pulseRing: {
          '0%': { transform: 'scale(.85)', opacity: '.7' },
          '100%': { transform: 'scale(1.6)', opacity: '0' },
        },
        gridmove: {
          '0%': { backgroundPosition: '0 0' },
          '100%': { backgroundPosition: '0 60px' },
        },
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        shimmer: 'shimmer 2.5s linear infinite',
        pulseRing: 'pulseRing 1.6s ease-out infinite',
        gridmove: 'gridmove 3s linear infinite',
      },
    },
  },
  plugins: [],
}
