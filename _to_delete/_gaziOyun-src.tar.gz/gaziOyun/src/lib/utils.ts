export const uid = (prefix = 'id') =>
  `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`

export const cx = (...parts: Array<string | false | null | undefined>) =>
  parts.filter(Boolean).join(' ')

export const fmtDate = (ts: number) =>
  new Date(ts).toLocaleString('tr-TR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })

export const fmtDuration = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000))
  const m = Math.floor(s / 60)
  const r = s % 60
  return m > 0 ? `${m} dk ${r} sn` : `${r} sn`
}

export const initials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toLocaleUpperCase('tr-TR') ?? '')
    .join('')

/** 0–100 arası oranı renk sınıfına çevirir */
export const scoreTone = (pct: number) =>
  pct >= 80
    ? 'text-emerald-300'
    : pct >= 50
      ? 'text-amber-300'
      : 'text-rose-300'

export const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n))
