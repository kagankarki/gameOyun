import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import Loader from '@/components/Loader'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/components/Toast'
import * as api from '@/lib/api'
import type { Attempt, Lesson } from '@/lib/types'
import { EASE } from '@/lib/motion'
import { cx, fmtDuration, uid } from '@/lib/utils'

const FALSE_ALARM_PENALTY = 40

type Judge = { kind: 'hit' | 'miss' | 'false'; text: string; points: number } | null

export default function LessonPlay() {
  const { id } = useParams()
  const nav = useNavigate()
  const toast = useToast()
  const { user } = useAuth()

  const [lesson, setLesson] = useState<Lesson | null>(null)
  const [loading, setLoading] = useState(true)
  const [i, setI] = useState(0)
  const [score, setScore] = useState(0)
  const [flagged, setFlagged] = useState<string[]>([])
  const [judge, setJudge] = useState<Judge>(null)
  const [locked, setLocked] = useState(false)
  const [done, setDone] = useState(false)
  const [saved, setSaved] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const startedAt = useRef(Date.now())
  const results = useRef<{ correct: number; missed: number; falseAlarm: number }>({
    correct: 0,
    missed: 0,
    falseAlarm: 0,
  })

  useEffect(() => {
    let alive = true
    api.getLesson(id!).then((l) => {
      if (!alive) return
      setLesson(l)
      setLoading(false)
      startedAt.current = Date.now()
    })
    return () => {
      alive = false
    }
  }, [id])

  useEffect(() => {
    if (done) return
    const t = setInterval(() => setElapsed(Date.now() - startedAt.current), 1000)
    return () => clearInterval(t)
  }, [done])

  const block = lesson?.blocks[i]
  const total = lesson?.blocks.length ?? 0
  const traps = useMemo(() => lesson?.blocks.filter((b) => b.isWrong).length ?? 0, [lesson])

  const advance = useCallback(() => {
    setJudge(null)
    setLocked(false)
    if (i + 1 >= total) setDone(true)
    else setI(i + 1)
  }, [i, total])

  /* ── "Burada Yanlış Var!" ── */
  const flag = useCallback(() => {
    if (!block || locked || done) return
    setLocked(true)
    setFlagged((f) => [...f, block.id])

    if (block.isWrong) {
      const p = block.points ?? 100
      results.current.correct += 1
      setScore((s) => s + p)
      setJudge({
        kind: 'hit',
        points: p,
        text: block.correction || 'Doğru yakaladın!',
      })
    } else {
      results.current.falseAlarm += 1
      setScore((s) => s - FALSE_ALARM_PENALTY)
      setJudge({
        kind: 'false',
        points: -FALSE_ALARM_PENALTY,
        text: 'Bu bilgi doğruydu. Acele etme, dikkatli dinle.',
      })
    }
  }, [block, locked, done])

  /* ── "Devam" ── */
  const next = useCallback(() => {
    if (!block || done) return
    if (!locked && block.isWrong) {
      // hatayı kaçırdı
      results.current.missed += 1
      setLocked(true)
      setJudge({
        kind: 'miss',
        points: 0,
        text: block.correction || 'Burada bir hata vardı ve kaçırdın.',
      })
      return
    }
    advance()
  }, [block, locked, done, advance])

  /* ── Klavye kısayolları ── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (done) return
      if (e.code === 'Space') {
        e.preventDefault()
        flag()
      } else if (e.code === 'Enter' || e.code === 'ArrowRight') {
        e.preventDefault()
        next()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [flag, next, done])

  /* ── Bitişte sonucu kaydet ── */
  useEffect(() => {
    if (!done || saved || !lesson || !user) return
    const attempt: Attempt = {
      id: uid('att'),
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      studentId: user.uid,
      studentName: user.name,
      flagged,
      correct: results.current.correct,
      missed: results.current.missed,
      falseAlarm: results.current.falseAlarm,
      score: Math.max(0, score),
      durationMs: Date.now() - startedAt.current,
      finishedAt: Date.now(),
    }
    setSaved(true)
    api
      .saveAttempt(attempt)
      .then(() => toast('Sonucun kaydedildi.', 'success'))
      .catch(() => toast('Sonuç kaydedilemedi.', 'error'))
  }, [done, saved, lesson, user, score, flagged, toast])

  if (loading) return <Loader label="Ders hazırlanıyor…" />
  if (!lesson || lesson.blocks.length === 0)
    return (
      <div className="grid min-h-[70vh] place-items-center px-6 text-center">
        <div>
          <p className="text-5xl">🕳️</p>
          <h2 className="mt-4 font-display text-2xl font-bold">Ders bulunamadı ya da boş</h2>
          <div className="mt-6">
            <Button3D onClick={() => nav('/dersler')}>Derslere Dön</Button3D>
          </div>
        </div>
      </div>
    )

  /* ══════════════ SONUÇ EKRANI ══════════════ */
  if (done) {
    const acc = traps ? Math.round((results.current.correct / traps) * 100) : 100
    const medal = acc >= 90 ? '🥇' : acc >= 60 ? '🥈' : acc >= 30 ? '🥉' : '📚'
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mx-auto max-w-4xl px-5 py-14 sm:px-6"
      >
        <motion.div
          initial={{ scale: 0.9, y: 40, rotateX: 20 }}
          animate={{ scale: 1, y: 0, rotateX: 0 }}
          transition={{ type: 'spring', stiffness: 120, damping: 16 }}
          className="glass mb-8 p-10 text-center"
        >
          <motion.p
            initial={{ scale: 0 }}
            animate={{ scale: 1, rotate: [0, -12, 12, 0] }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-7xl"
          >
            {medal}
          </motion.p>
          <h1 className="mt-5 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Ders bitti!
          </h1>
          <p className="mt-2 text-slate-400">{lesson.title}</p>

          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="mt-8 font-display text-6xl font-bold text-amber-300 sm:text-7xl"
          >
            {Math.max(0, score)}
            <span className="ml-2 text-lg font-semibold text-amber-200/60">puan</span>
          </motion.p>

          <div className="mt-9 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ['Yakalanan', results.current.correct, 'text-emerald-300'],
              ['Kaçan', results.current.missed, 'text-slate-300'],
              ['Boşa basma', results.current.falseAlarm, 'text-rose-300'],
              ['Süre', fmtDuration(Date.now() - startedAt.current), 'text-indigo-300'],
            ].map(([k, v, c]) => (
              <div key={k as string} className="rounded-2xl border border-white/10 bg-black/25 p-4">
                <p className={cx('font-display text-2xl font-bold', c as string)}>{v as string}</p>
                <p className="mt-1 text-[10px] uppercase tracking-wider text-slate-500">
                  {k as string}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Button3D onClick={() => nav('/dersler')}>Derslere Dön</Button3D>
            <Button3D tone="gold" onClick={() => nav('/siralama')}>
              Sıralamayı Gör
            </Button3D>
            <Button3D tone="ghost" onClick={() => window.location.reload()}>
              Tekrar Oyna
            </Button3D>
          </div>
        </motion.div>

        {/* Ders tekrarı */}
        <h2 className="mb-4 font-display text-xl font-bold tracking-tight">Ders tekrarı</h2>
        <div className="space-y-3">
          {lesson.blocks.map((b, idx) => {
            const wasFlagged = flagged.includes(b.id)
            const state = b.isWrong
              ? wasFlagged
                ? 'hit'
                : 'miss'
              : wasFlagged
                ? 'false'
                : 'ok'
            const styles = {
              hit: 'border-emerald-400/40 bg-emerald-500/[0.08]',
              miss: 'border-amber-400/40 bg-amber-500/[0.08]',
              false: 'border-rose-400/40 bg-rose-500/[0.08]',
              ok: 'border-white/10 bg-white/[0.035]',
            }[state]
            const badge = {
              hit: ['✓ Yakaladın', 'text-emerald-300'],
              miss: ['✕ Kaçırdın', 'text-amber-300'],
              false: ['! Boşa bastın', 'text-rose-300'],
              ok: ['Doğru bilgi', 'text-slate-500'],
            }[state]

            return (
              <motion.div
                key={b.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.04 }}
                className={cx('rounded-2xl border p-5 backdrop-blur-md', styles)}
              >
                <div className="mb-2 flex items-center gap-3">
                  <span className="grid h-6 w-6 place-items-center rounded-md bg-white/8 font-mono text-[11px] text-slate-400">
                    {idx + 1}
                  </span>
                  <span className={cx('text-xs font-semibold', badge[1])}>{badge[0]}</span>
                </div>
                <p className="text-[15px] leading-relaxed text-slate-200">{b.text}</p>
                {b.isWrong && b.correction && (
                  <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3 text-sm text-emerald-100/90">
                    <strong className="font-semibold">Doğrusu:</strong> {b.correction}
                  </p>
                )}
              </motion.div>
            )
          })}
        </div>
      </motion.div>
    )
  }

  /* ══════════════ OYUN EKRANI ══════════════ */
  const progress = ((i + (locked ? 1 : 0)) / total) * 100

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="scene mx-auto flex min-h-[calc(100vh-70px)] max-w-4xl flex-col px-5 py-8 sm:px-6"
    >
      {/* Üst bilgi çubuğu */}
      <div className="glass-soft mb-6 flex flex-wrap items-center gap-4 px-5 py-3.5">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-white">{lesson.title}</p>
          <p className="text-[11px] text-indigo-300/80">{lesson.teacherName}</p>
        </div>
        <div className="ml-auto flex items-center gap-4 text-sm">
          <span className="text-slate-400">
            {i + 1}/{total}
          </span>
          <span className="text-indigo-300">{fmtDuration(elapsed)}</span>
          <span className="font-display text-lg font-bold text-amber-300">{Math.max(0, score)}</span>
        </div>
      </div>

      {/* İlerleme */}
      <div className="mb-8 h-1.5 overflow-hidden rounded-full bg-white/8">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-indigo-400 via-cyan-400 to-emerald-400"
          animate={{ width: `${progress}%` }}
          transition={{ type: 'spring', stiffness: 120, damping: 20 }}
        />
      </div>

      {/* Ders kartı */}
      <div className="preserve-3d flex flex-1 items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={block?.id}
            initial={{ opacity: 0, y: 60, rotateX: -28, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, rotateX: 24, scale: 0.94 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="preserve-3d w-full"
          >
            <div
              className={cx(
                'glass relative overflow-hidden p-8 transition-colors duration-500 sm:p-12',
                judge?.kind === 'hit' && 'border-emerald-400/50',
                judge?.kind === 'false' && 'border-rose-400/50',
                judge?.kind === 'miss' && 'border-amber-400/50',
              )}
            >
              <div className="absolute inset-0 grid-floor animate-gridmove opacity-[0.18] [mask-image:radial-gradient(ellipse_at_center,black,transparent_78%)]" />

              <div className="relative">
                <p className="mb-6 text-[11px] font-semibold uppercase tracking-[0.24em] text-indigo-300/70">
                  Bölüm {i + 1}
                </p>

                <p className="font-display text-xl leading-[1.6] text-slate-100 sm:text-[26px] sm:leading-[1.55]">
                  {block?.text}
                </p>

                {/* Hakem kutusu */}
                <AnimatePresence>
                  {judge && (
                    <motion.div
                      initial={{ opacity: 0, y: 20, scale: 0.96 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ type: 'spring', stiffness: 260, damping: 22 }}
                      className={cx(
                        'mt-8 rounded-2xl border p-5',
                        judge.kind === 'hit' && 'border-emerald-400/40 bg-emerald-500/12',
                        judge.kind === 'false' && 'border-rose-400/40 bg-rose-500/12',
                        judge.kind === 'miss' && 'border-amber-400/40 bg-amber-500/12',
                      )}
                    >
                      <div className="mb-2 flex items-center gap-3">
                        <span className="text-2xl">
                          {judge.kind === 'hit' ? '🎯' : judge.kind === 'false' ? '🛑' : '😬'}
                        </span>
                        <span
                          className={cx(
                            'font-display text-lg font-bold',
                            judge.kind === 'hit' && 'text-emerald-300',
                            judge.kind === 'false' && 'text-rose-300',
                            judge.kind === 'miss' && 'text-amber-300',
                          )}
                        >
                          {judge.kind === 'hit'
                            ? 'Hatayı yakaladın!'
                            : judge.kind === 'false'
                              ? 'Burada hata yoktu'
                              : 'Hatayı kaçırdın'}
                        </span>
                        {judge.points !== 0 && (
                          <motion.span
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={cx(
                              'ml-auto font-display text-lg font-bold',
                              judge.points > 0 ? 'text-emerald-300' : 'text-rose-300',
                            )}
                          >
                            {judge.points > 0 ? `+${judge.points}` : judge.points}
                          </motion.span>
                        )}
                      </div>
                      <p className="text-sm leading-relaxed text-slate-200/90">{judge.text}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Aksiyonlar */}
      <div className="mt-8 flex flex-col items-center gap-4 pb-6">
        <div className="flex flex-wrap items-center justify-center gap-4">
          <div className="relative">
            {!locked && (
              <span className="absolute inset-0 rounded-3xl bg-rose-500/35 animate-pulseRing" />
            )}
            <Button3D tone="danger" size="xl" icon="🚨" onClick={flag} disabled={locked}>
              Burada Yanlış Var!
            </Button3D>
          </div>

          <Button3D
            tone={locked ? 'primary' : 'ghost'}
            size="xl"
            onClick={next}
            icon={i + 1 >= total ? '🏁' : '→'}
          >
            {locked ? (i + 1 >= total ? 'Bitir' : 'Devam Et') : i + 1 >= total ? 'Bitir' : 'Doğru, geç'}
          </Button3D>
        </div>

        <p className="text-[11px] text-slate-500">
          Kısayol: <kbd className="rounded bg-white/10 px-1.5 py-0.5">Boşluk</kbd> = yanlış bildir ·{' '}
          <kbd className="rounded bg-white/10 px-1.5 py-0.5">Enter</kbd> = devam
        </p>
      </div>
    </motion.div>
  )
}
