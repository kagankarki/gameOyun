import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import Loader from '@/components/Loader'
import * as api from '@/lib/api'
import type { Attempt, Lesson } from '@/lib/types'
import { cx, fmtDate, fmtDuration, initials, scoreTone } from '@/lib/utils'

export default function LiveResults() {
  const { id } = useParams()
  const nav = useNavigate()
  const [lesson, setLesson] = useState<Lesson | null>(null)
  const [attempts, setAttempts] = useState<Attempt[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getLesson(id!).then((l) => {
      setLesson(l)
      setLoading(false)
    })
  }, [id])

  useEffect(() => api.watchAttempts(setAttempts, id), [id])

  /** Blok bazlı: kaç öğrenci bu bloğa "yanlış" dedi? */
  const perBlock = useMemo(() => {
    if (!lesson) return []
    return lesson.blocks.map((b) => {
      const hits = attempts.filter((a) => a.flagged.includes(b.id)).length
      const pct = attempts.length ? Math.round((hits / attempts.length) * 100) : 0
      return { block: b, hits, pct }
    })
  }, [lesson, attempts])

  const summary = useMemo(() => {
    const students = new Set(attempts.map((a) => a.studentId)).size
    const avg = attempts.length
      ? Math.round(attempts.reduce((s, a) => s + a.score, 0) / attempts.length)
      : 0
    const hits = attempts.reduce((s, a) => s + a.correct, 0)
    const chances = attempts.reduce((s, a) => s + a.correct + a.missed, 0)
    return {
      students,
      plays: attempts.length,
      avg,
      rate: chances ? Math.round((hits / chances) * 100) : 0,
    }
  }, [attempts])

  if (loading) return <Loader label="Sonuçlar getiriliyor…" />
  if (!lesson)
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <Button3D onClick={() => nav('/hoca')}>Panele Dön</Button3D>
      </div>
    )

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="mx-auto max-w-6xl px-5 py-12 sm:px-6"
    >
      <button
        onClick={() => nav('/hoca')}
        className="mb-6 text-sm text-slate-400 transition-colors hover:text-white"
      >
        ← Panele dön
      </button>

      <div className="mb-9">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-indigo-300">
          Canlı sonuçlar
        </p>
        <h1 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          {lesson.title}
        </h1>
      </div>

      <div className="mb-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          ['Katılan öğrenci', summary.students],
          ['Toplam deneme', summary.plays],
          ['Ortalama puan', summary.avg],
          ['Hata yakalama', `%${summary.rate}`],
        ].map(([k, v]) => (
          <div key={k as string} className="glass-soft p-5">
            <p className="font-display text-3xl font-bold text-white">{v as string}</p>
            <p className="mt-1 text-xs uppercase tracking-wider text-slate-400">{k as string}</p>
          </div>
        ))}
      </div>

      {/* Blok analizi */}
      <section className="mb-12">
        <h2 className="mb-4 font-display text-xl font-bold tracking-tight">
          Blok analizi{' '}
          <span className="text-sm font-normal text-slate-400">
            — hangi cümleye kaç kişi “yanlış” dedi
          </span>
        </h2>
        <div className="space-y-3">
          {perBlock.map(({ block, hits, pct }, idx) => (
            <div
              key={block.id}
              className={cx(
                'rounded-2xl border p-5 backdrop-blur-md',
                block.isWrong
                  ? 'border-rose-400/35 bg-rose-500/[0.07]'
                  : 'border-white/10 bg-white/[0.035]',
              )}
            >
              <div className="mb-2 flex flex-wrap items-center gap-3">
                <span className="grid h-6 w-6 place-items-center rounded-md bg-white/8 font-mono text-[11px] text-slate-400">
                  {idx + 1}
                </span>
                {block.isWrong ? (
                  <span className="rounded-lg bg-rose-500/15 px-2 py-0.5 text-[11px] font-semibold text-rose-300">
                    TUZAK · {block.points ?? 100} puan
                  </span>
                ) : (
                  <span className="rounded-lg bg-white/6 px-2 py-0.5 text-[11px] font-semibold text-slate-400">
                    DOĞRU BİLGİ
                  </span>
                )}
                <span className="ml-auto text-sm">
                  <span
                    className={cx(
                      'font-display font-bold',
                      block.isWrong ? scoreTone(pct) : pct > 25 ? 'text-rose-300' : 'text-slate-400',
                    )}
                  >
                    {hits}
                  </span>
                  <span className="text-slate-500"> kişi · %{pct}</span>
                </span>
              </div>

              <p className="text-[15px] leading-relaxed text-slate-200">{block.text}</p>

              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/8">
                <div
                  className={cx(
                    'h-full rounded-full transition-all duration-700',
                    block.isWrong
                      ? 'bg-gradient-to-r from-emerald-400 to-teal-400'
                      : 'bg-gradient-to-r from-rose-400 to-orange-400',
                  )}
                  style={{ width: `${pct}%` }}
                />
              </div>

              {block.isWrong && block.correction && (
                <p className="mt-3 text-xs text-emerald-200/70">Doğrusu: {block.correction}</p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Öğrenci tablosu */}
      <section>
        <h2 className="mb-4 font-display text-xl font-bold tracking-tight">Öğrenci sonuçları</h2>
        {attempts.length === 0 ? (
          <div className="glass grid place-items-center p-14 text-center">
            <p className="text-4xl">⏳</p>
            <p className="mt-4 text-sm text-slate-400">
              Henüz kimse bu dersi oynamadı. Yayına aldıysan sonuçlar buraya anlık düşecek.
            </p>
          </div>
        ) : (
          <div className="glass overflow-hidden">
            <div className="hidden grid-cols-[1fr_repeat(5,88px)] gap-2 border-b border-white/10 px-6 py-3 text-[11px] font-semibold uppercase tracking-wider text-slate-400 sm:grid">
              <span>Öğrenci</span>
              <span className="text-right">Yakalanan</span>
              <span className="text-right">Kaçan</span>
              <span className="text-right">Boş</span>
              <span className="text-right">Süre</span>
              <span className="text-right">Puan</span>
            </div>
            {attempts.map((a) => (
              <div
                key={a.id}
                className="grid grid-cols-2 gap-2 border-b border-white/6 px-6 py-4 text-sm last:border-0 sm:grid-cols-[1fr_repeat(5,88px)]"
              >
                <div className="col-span-2 flex items-center gap-3 sm:col-span-1">
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-indigo-400 to-cyan-400 text-[11px] font-bold text-ink-900">
                    {initials(a.studentName)}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate font-semibold text-white">{a.studentName}</p>
                    <p className="text-[11px] text-slate-500">{fmtDate(a.finishedAt)}</p>
                  </div>
                </div>
                <span className="text-right text-emerald-300">{a.correct}</span>
                <span className="text-right text-slate-400">{a.missed}</span>
                <span className="text-right text-rose-300">{a.falseAlarm}</span>
                <span className="text-right text-slate-400">{fmtDuration(a.durationMs)}</span>
                <span className="text-right font-display font-bold text-amber-300">{a.score}</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </motion.div>
  )
}
