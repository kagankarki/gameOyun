import { useState, type FormEvent } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import Logo from '@/components/Logo'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/components/Toast'
import { TEACHER_CODE } from '@/lib/firebase'
import { isFirebaseConfigured } from '@/lib/api'
import { EASE } from '@/lib/motion'
import { cx } from '@/lib/utils'
import type { Role } from '@/lib/types'

const field =
  'w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-3.5 text-sm text-white placeholder-slate-500 outline-none transition-all focus:border-indigo-400/60 focus:bg-white/[0.09] focus:ring-4 focus:ring-indigo-500/15'

export default function Login() {
  const [params] = useSearchParams()
  const nav = useNavigate()
  const toast = useToast()
  const { signIn, signUp } = useAuth()

  const [mode, setMode] = useState<'in' | 'up'>('up')
  const [role, setRole] = useState<Role>(params.get('rol') === 'teacher' ? 'teacher' : 'student')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    try {
      if (mode === 'in') {
        const u = await signIn(email.trim(), password)
        toast(`Hoş geldin ${u.name}!`, 'success')
        nav(u.role === 'teacher' ? '/hoca' : '/dersler')
      } else {
        if (!name.trim()) throw new Error('Ad soyad gerekli.')
        if (role === 'teacher' && code.trim() !== TEACHER_CODE) {
          throw new Error('Öğretim üyesi kodu hatalı.')
        }
        const u = await signUp(name.trim(), email.trim(), password, role)
        toast('Hesabın oluşturuldu 🎉', 'success')
        nav(u.role === 'teacher' ? '/hoca' : '/dersler')
      }
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
              .replace('Firebase: ', '')
              .replace('auth/invalid-credential', 'E-posta veya şifre hatalı')
              .replace('auth/email-already-in-use', 'Bu e-posta zaten kayıtlı')
              .replace('auth/weak-password', 'Şifre en az 6 karakter olmalı')
              .replace('auth/invalid-email', 'Geçersiz e-posta')
          : 'Bir şeyler ters gitti.'
      toast(msg, 'error')
    } finally {
      setBusy(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="scene mx-auto grid min-h-[calc(100vh-70px)] max-w-lg place-items-center px-5 py-14"
    >
      <motion.div
        initial={{ opacity: 0, y: 40, rotateX: 22 }}
        animate={{ opacity: 1, y: 0, rotateX: 0 }}
        transition={{ duration: 0.75, ease: EASE }}
        className="preserve-3d w-full"
      >
        <div className="glass p-8 sm:p-10">
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="animate-float">
              <Logo size={58} />
            </div>
            <h1 className="mt-5 font-display text-2xl font-bold tracking-tight">
              {mode === 'up' ? 'Aramıza katıl' : 'Tekrar hoş geldin'}
            </h1>
            <p className="mt-2 text-sm text-slate-400">
              Gazi Üniversitesi · Hatayı Yakala platformu
            </p>
          </div>

          {/* mod seçici */}
          <div className="mb-7 grid grid-cols-2 gap-1 rounded-2xl border border-white/10 bg-black/25 p-1">
            {(
              [
                ['up', 'Kayıt Ol'],
                ['in', 'Giriş Yap'],
              ] as const
            ).map(([m, label]) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={cx(
                  'relative rounded-xl py-2.5 text-sm font-semibold transition-colors',
                  mode === m ? 'text-white' : 'text-slate-400 hover:text-slate-200',
                )}
              >
                {mode === m && (
                  <motion.span
                    layoutId="authpill"
                    className="absolute inset-0 rounded-xl bg-gradient-to-b from-indigo-500 to-indigo-600 shadow-lg shadow-indigo-900/50"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative">{label}</span>
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'up' && (
              <>
                {/* rol seçimi */}
                <div className="grid grid-cols-2 gap-3">
                  {(
                    [
                      ['student', 'Öğrenci', '🎓'],
                      ['teacher', 'Öğretim Üyesi', '🧑‍🏫'],
                    ] as const
                  ).map(([r, label, icon]) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={cx(
                        'rounded-2xl border p-4 text-center transition-all duration-200',
                        role === r
                          ? 'border-indigo-400/70 bg-indigo-500/15 shadow-neon -translate-y-0.5'
                          : 'border-white/10 bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.06]',
                      )}
                    >
                      <span className="block text-2xl">{icon}</span>
                      <span className="mt-2 block text-xs font-semibold text-slate-200">
                        {label}
                      </span>
                    </button>
                  ))}
                </div>

                <input
                  className={field}
                  placeholder="Ad Soyad"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
              </>
            )}

            <input
              className={field}
              type="email"
              required
              placeholder="E-posta"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
            <input
              className={field}
              type="password"
              required
              minLength={6}
              placeholder="Şifre (en az 6 karakter)"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === 'up' ? 'new-password' : 'current-password'}
            />

            {mode === 'up' && role === 'teacher' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <input
                  className={cx(field, 'border-amber-400/30 bg-amber-400/[0.06]')}
                  placeholder="Öğretim üyesi kodu"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
                <p className="mt-2 px-1 text-[11px] text-amber-200/70">
                  Varsayılan kod: <code className="font-semibold">{TEACHER_CODE}</code> — .env
                  dosyasından değiştirebilirsin.
                </p>
              </motion.div>
            )}

            <Button3D type="submit" size="lg" full disabled={busy}>
              {busy ? 'Lütfen bekle…' : mode === 'up' ? 'Hesap Oluştur' : 'Giriş Yap'}
            </Button3D>
          </form>

          {!isFirebaseConfigured && (
            <div className="mt-7 rounded-2xl border border-amber-400/25 bg-amber-400/[0.07] p-4 text-[12px] leading-relaxed text-amber-100/85">
              <strong className="font-semibold">Demo mod:</strong> Firebase bilgileri girilmediği
              için hesaplar ve dersler bu tarayıcıda saklanıyor. Gerçek çok kullanıcılı kullanım
              için <code>.env.example</code> dosyasını <code>.env</code> olarak kopyalayıp Firebase
              anahtarlarını gir.
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}
