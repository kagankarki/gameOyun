import {
  useRef,
  useState,
  type CSSProperties,
  type MouseEvent as ReactMouseEvent,
  type ReactNode,
} from 'react'
import { cx } from '@/lib/utils'

interface Props {
  children: ReactNode
  className?: string
  /** Maksimum eğilme açısı (derece) */
  max?: number
  /** İçeriğin kart yüzeyinden ne kadar "çıkacağı" (px) */
  lift?: number
  glare?: boolean
  style?: CSSProperties
}

/**
 * Fareye göre gerçek 3B perspektifle eğilen kart.
 * İçerik translateZ ile yüzeyden yukarı kaldırılır → derinlik hissi.
 */
export default function TiltCard({
  children,
  className,
  max = 9,
  lift = 26,
  glare = true,
  style,
}: Props) {
  const ref = useRef<HTMLDivElement>(null)
  const [t, setT] = useState({ rx: 0, ry: 0, gx: 50, gy: 50, active: false })

  const onMove = (e: ReactMouseEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width
    const py = (e.clientY - r.top) / r.height
    setT({
      rx: (0.5 - py) * 2 * max,
      ry: (px - 0.5) * 2 * max,
      gx: px * 100,
      gy: py * 100,
      active: true,
    })
  }

  const onLeave = () => setT((s) => ({ ...s, rx: 0, ry: 0, active: false }))

  return (
    <div className="scene" style={style}>
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className={cx(
          'preserve-3d relative transition-transform duration-200 ease-out will-change-transform',
          className,
        )}
        style={{
          transform: `rotateX(${t.rx}deg) rotateY(${t.ry}deg) translateZ(0)`,
        }}
      >
        <div className="preserve-3d" style={{ transform: `translateZ(${lift}px)` }}>
          {children}
        </div>

        {glare && (
          <div
            className="pointer-events-none absolute inset-0 rounded-3xl opacity-0 transition-opacity duration-300"
            style={{
              opacity: t.active ? 1 : 0,
              background: `radial-gradient(520px circle at ${t.gx}% ${t.gy}%, rgba(255,255,255,.13), transparent 42%)`,
            }}
          />
        )}
      </div>
    </div>
  )
}
