import { Component, Suspense, lazy, type ReactNode } from 'react'

const Scene3D = lazy(() => import('./Scene3D'))

/** WebGL desteklenmeyen cihazlarda kullanılan saf CSS arka planı. */
function CssFallback() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-900">
      <div className="absolute -left-40 -top-40 h-[620px] w-[620px] rounded-full bg-indigo-600/25 blur-[120px]" />
      <div className="absolute -right-32 top-24 h-[520px] w-[520px] rounded-full bg-cyan-500/20 blur-[120px]" />
      <div className="absolute bottom-[-180px] left-1/3 h-[560px] w-[560px] rounded-full bg-violet-500/20 blur-[130px]" />
      <div className="absolute inset-0 grid-floor animate-gridmove opacity-30 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
    </div>
  )
}

interface State {
  failed: boolean
}

/**
 * 3B sahne herhangi bir nedenle (WebGL yok, sürücü hatası vb.) çökerse
 * site kapanmasın diye sahneyi hata sınırı içine alır.
 */
export default class SceneBoundary extends Component<
  { dim?: number; children?: ReactNode },
  State
> {
  state: State = { failed: false }

  static getDerivedStateFromError(): State {
    return { failed: true }
  }

  componentDidCatch(error: unknown) {
    console.warn('[Scene3D] devre dışı bırakıldı:', error)
  }

  render() {
    if (this.state.failed) return <CssFallback />
    return (
      <Suspense fallback={<CssFallback />}>
        <Scene3D dim={this.props.dim} />
      </Suspense>
    )
  }
}
