import { Suspense, useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial, Sparkles, Stars } from '@react-three/drei'
import * as THREE from 'three'

/* ── Fareyi takip eden yumuşak kamera ────────────────────── */
function CameraRig() {
  useFrame((state, delta) => {
    const x = (state.pointer.x * 1.6)
    const y = (state.pointer.y * 0.9)
    state.camera.position.x += (x - state.camera.position.x) * Math.min(1, delta * 1.8)
    state.camera.position.y += (y - state.camera.position.y) * Math.min(1, delta * 1.8)
    state.camera.lookAt(0, 0, 0)
  })
  return null
}

/* ── Dönen ana çekirdek ──────────────────────────────────── */
function Core() {
  const ref = useRef<THREE.Mesh>(null)
  useFrame((_, delta) => {
    if (!ref.current) return
    ref.current.rotation.y += delta * 0.16
    ref.current.rotation.x += delta * 0.06
  })
  return (
    <Float speed={1.1} rotationIntensity={0.5} floatIntensity={1.1}>
      <mesh ref={ref} position={[0, 0, 0]} scale={2.1}>
        <icosahedronGeometry args={[1, 6]} />
        <MeshDistortMaterial
          color="#4f46e5"
          emissive="#1e1b4b"
          emissiveIntensity={0.55}
          roughness={0.15}
          metalness={0.85}
          distort={0.34}
          speed={1.4}
        />
      </mesh>
    </Float>
  )
}

/* ── Etrafta süzülen kristaller ──────────────────────────── */
type ShardProps = { position: [number, number, number]; color: string; scale?: number; kind?: number }

function Shard({ position, color, scale = 1, kind = 0 }: ShardProps) {
  const ref = useRef<THREE.Mesh>(null)
  const spin = useMemo(() => 0.2 + Math.random() * 0.35, [])
  useFrame((_, delta) => {
    if (!ref.current) return
    ref.current.rotation.x += delta * spin
    ref.current.rotation.z += delta * spin * 0.6
  })
  const geo =
    kind === 0 ? (
      <octahedronGeometry args={[1, 0]} />
    ) : kind === 1 ? (
      <torusGeometry args={[0.75, 0.24, 16, 48]} />
    ) : (
      <tetrahedronGeometry args={[1.1, 0]} />
    )

  return (
    <Float speed={1.4} rotationIntensity={1} floatIntensity={1.8}>
      <mesh ref={ref} position={position} scale={scale}>
        {geo}
        <meshStandardMaterial
          color={color}
          roughness={0.2}
          metalness={0.9}
          emissive={color}
          emissiveIntensity={0.28}
        />
      </mesh>
    </Float>
  )
}

function SceneContents({ intensity }: { intensity: number }) {
  return (
    <>
      <color attach="background" args={['#05060f']} />
      <fog attach="fog" args={['#05060f', 9, 26]} />

      <ambientLight intensity={0.55} />
      <directionalLight position={[6, 8, 5]} intensity={2.1} color="#a5b4fc" />
      <pointLight position={[-7, -4, -4]} intensity={45} color="#22d3ee" distance={26} />
      <pointLight position={[7, 5, -6]} intensity={38} color="#a78bfa" distance={26} />

      <Core />

      <Shard position={[-4.4, 1.7, -2]} color="#22d3ee" scale={0.62} kind={0} />
      <Shard position={[4.5, -1.4, -1.4]} color="#a78bfa" scale={0.5} kind={1} />
      <Shard position={[3.4, 2.4, -3.4]} color="#fbbf24" scale={0.38} kind={2} />
      <Shard position={[-3.6, -2.3, -2.8]} color="#fb7185" scale={0.42} kind={0} />
      <Shard position={[0.4, 3.2, -4.6]} color="#818cf8" scale={0.34} kind={1} />

      <Sparkles count={70} scale={[16, 10, 10]} size={2.4} speed={0.32} color="#c7d2fe" opacity={0.7} />
      <Stars radius={70} depth={42} count={intensity > 0.5 ? 2200 : 900} factor={3.4} saturation={0} fade speed={0.6} />

      <CameraRig />
    </>
  )
}

/**
 * Tüm sayfanın arkasında duran WebGL sahnesi.
 * `dim` ile içerik okunurluğu için karartma miktarı ayarlanır.
 */
export default function Scene3D({ dim = 0.55, quality = 1 }: { dim?: number; quality?: number }) {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10">
      <Canvas
        dpr={[1, 1.6]}
        camera={{ position: [0, 0, 9], fov: 52 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
      >
        <Suspense fallback={null}>
          <SceneContents intensity={quality} />
        </Suspense>
      </Canvas>

      {/* Okunabilirlik katmanı */}
      <div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(ellipse at 50% 35%, rgba(5,6,15,${dim * 0.35}) 0%, rgba(5,6,15,${dim}) 55%, rgba(5,6,15,${Math.min(0.96, dim + 0.3)}) 100%)`,
        }}
      />
      {/* İnce grain dokusu */}
      <div className="absolute inset-0 opacity-[0.045] mix-blend-overlay [background-image:url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22120%22 height=%22120%22><filter id=%22n%22><feTurbulence type=%22fractalNoise%22 baseFrequency=%220.9%22 numOctaves=%223%22/></filter><rect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23n)%22/></svg>')]" />
    </div>
  )
}
