import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import TiltCard from '@/components/TiltCard'
import { useAuth } from '@/context/AuthContext'
import * as api from '@/lib/api'
import type { Attempt } from '@/lib/types'
import { cx, initials } from '@/lib/utils'

export default function Leaderboard() {
  const { user } = useAuth()
  const [attempts, setAttempts] = useState<Attempt[]>([])
  useEffect(() => api.watchAttempts(setAttempts), [])

  const rows = useMemo(() => api.buildLeaderboard(attempts), [attempts])
  const podium = rows.slice(0, 3)

  const order = [1, 0, 2] // görsel podyum sırası: 2. – 1. – 3.
  const heights = ['h-28', 'h-40', 'h-20']
  const medals = ['🥈', '🥇', '🥉']

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="mx-auto max-w-4xl px-5 py-12 sm:px-6"
    >
      <div className="mb-12 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-indigo-300">
          Sıralama
        </p>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <span className="title-grad">Hata Avcıları</span>
        </h1>
        <p className="mt-3 text-sm text-slate-400">
          Tüm derslerden toplanan puanlara göre genel sıralama
        </p>
      </div>

      {rows.length === 0 ? (
        <div className="glass grid place-items-center p-16 text-center">
          <p className="text-5xl">🏁</p>
          <p className="mt-5 text-sm text-slate-400">
            Henüz kimse ders tamamlamadı. İlk sırayı sen kap!
          </p>
        </div>
      ) : (
        <>
          {/* Podyum */}
          <div className="scene mb-14 flex items-end justify-center gap-3 sm:gap-6">
            {order.map((slot, visualIdx) => {
              const r = podium[slot]
              if (!r) return <div key={visualIdx} className="w-24 sm:w-32" />
              const isMe = r.studentId === user?.uid
              return (
                <motion.div
                  key={r.studentId}
                  initial={{ opacity: 0, y: 60, rotateX: 30 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ delay: visualIdx * 0.12, type: 'spring', stiffness: 110, damping: 15 }}
                  className="preserve-3d flex w-24 flex-col items-center sm:w-36"
                >
                  <span className="mb-2 text-3xl sm:text-4xl">{medals[visualIdx]}</span>
                  <div
                    className={cx(
                      'grid h-12 w-12 place-items-center rounded-2xl text-sm font-bold sm:h-14 sm:w-14',
                      slot === 0
                        ? 'bg-gradient-to-br from-amber-300 to-yellow-500 text-amber-950'
                        : 'bg-gradient-to-br from-indigo-400 to-cyan-400 text-ink-900',
                    )}
                  >
                    {initials(r.studentName)}
                  </div>
                  <p className="mt-2.5 line-clamp-1 text-center text-xs font-semibold text-white">
                    {r.studentName}
                    {isMe && <span className="text-indigo-300"> (sen)</span>}
                  </p>
                  <p className="font-display text-lg font-bold text-amber-300">{r.totalScore}</p>
                  <div
                    className={cx(
                      'mt-3 w-full rounded-t-2xl border border-b-0 border-white/12 bg-gradient-to-b from-white/12 to-white/[0.02] backdrop-blur-md',
                      heights[visualIdx],
                    )}
                  />
                </motion.div>
              )
            })}
          </div>

          {/* Tam liste */}
          <TiltCard max={4} lift={12}>
            <div className="glass overflow-hidden">
              <div className="grid grid-cols-[40px_1fr_70px_70px_80px] gap-2 border-b border-white/10 px-5 py-3 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                <span>#</span>
                <span>Öğrenci</span>
                <span className="text-right">Ders</span>
                <span className="text-right">İsabet</span>
                <span className="text-right">Puan</span>
              </div>
              {rows.map((r, i) => {
                const isMe = r.studentId === user?.uid
                return (
                  <motion.div
                    key={r.studentId}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: Math.min(i, 12) * 0.03 }}
                    className={cx(
                      'grid grid-cols-[40px_1fr_70px_70px_80px] items-center gap-2 border-b border-white/6 px-5 py-3.5 text-sm last:border-0',
                      isMe && 'bg-indigo-500/10',
                    )}
                  >
                    <span
                      className={cx(
                        'font-display font-bold',
                        i === 0
                          ? 'text-amber-300'
                          : i === 1
                            ? 'text-slate-300'
                            : i === 2
                              ? 'text-orange-300'
                              : 'text-slate-500',
                      )}
                    >
                      {i + 1}
                    </span>
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/8 text-[11px] font-bold text-slate-200">
                        {initials(r.studentName)}
                      </div>
                      <p className="truncate font-medium text-white">
                        {r.studentName}
                        {isMe && <span className="ml-1.5 text-xs text-indigo-300">sen</span>}
                      </p>
                    </div>
                    <span className="text-right text-slate-400">{r.attempts}</span>
                    <span className="text-right text-cyan-300">%{r.accuracy}</span>
                    <span className="text-right font-display font-bold text-amber-300">
                      {r.totalScore}
                    </span>
                  </motion.div>
                )
              })}
            </div>
          </TiltCard>
        </>
      )}
    </motion.div>
  )
}
