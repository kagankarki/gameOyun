/**
 * DEMO MOD deposu — Firebase yapılandırılmadığında devreye girer.
 * Veriler tarayıcının localStorage'ında tutulur, sekmeler arasında senkronlanır.
 */
import type { AppUser, Attempt, Lesson } from './types'
import { demoLesson } from './seed'

const K = {
  users: 'hy.users',
  creds: 'hy.creds',
  session: 'hy.session',
  lessons: 'hy.lessons',
  attempts: 'hy.attempts',
  seeded: 'hy.seeded.v1',
}

type Listener = () => void
const listeners = new Set<Listener>()

export const notify = () => {
  listeners.forEach((l) => {
    try {
      l()
    } catch (e) {
      console.error(e)
    }
  })
}

export const subscribe = (fn: Listener) => {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', () => notify())
}

const read = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

const write = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (e) {
    console.error('localStorage yazılamadı', e)
  }
  notify()
}

/* ── Tohumlama ─────────────────────────────────────────── */
export const ensureSeed = () => {
  if (typeof window === 'undefined') return
  if (localStorage.getItem(K.seeded)) return
  const lessons = read<Lesson[]>(K.lessons, [])
  if (!lessons.some((l) => l.id === 'demo_anatomi_1')) {
    lessons.push(demoLesson())
    localStorage.setItem(K.lessons, JSON.stringify(lessons))
  }
  localStorage.setItem(K.seeded, '1')
}

/* ── Kullanıcılar ──────────────────────────────────────── */
export const getUsers = () => read<AppUser[]>(K.users, [])
export const putUser = (u: AppUser) => {
  const users = getUsers().filter((x) => x.uid !== u.uid)
  users.push(u)
  write(K.users, users)
}
export const getCreds = () => read<Record<string, string>>(K.creds, {})
export const putCred = (email: string, password: string) => {
  const c = getCreds()
  c[email.toLowerCase()] = password
  write(K.creds, c)
}
export const getSession = () => read<string | null>(K.session, null)
export const setSession = (uidValue: string | null) => write(K.session, uidValue)

/* ── Dersler ───────────────────────────────────────────── */
export const getLessons = () => read<Lesson[]>(K.lessons, [])
export const putLesson = (l: Lesson) => {
  const list = getLessons().filter((x) => x.id !== l.id)
  list.push(l)
  write(K.lessons, list)
}
export const removeLesson = (id: string) => {
  write(K.lessons, getLessons().filter((l) => l.id !== id))
  write(K.attempts, getAttempts().filter((a) => a.lessonId !== id))
}

/* ── Denemeler ─────────────────────────────────────────── */
export const getAttempts = () => read<Attempt[]>(K.attempts, [])
export const putAttempt = (a: Attempt) => {
  const list = getAttempts().filter((x) => x.id !== a.id)
  list.push(a)
  write(K.attempts, list)
}

export const wipeAll = () => {
  Object.values(K).forEach((k) => localStorage.removeItem(k))
  notify()
}
