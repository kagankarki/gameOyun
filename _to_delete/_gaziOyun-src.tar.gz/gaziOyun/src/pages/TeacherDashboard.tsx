import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import TiltCard from '@/components/TiltCard'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/components/Toast'
import * as api from '@/lib/api'
import type { Attempt, Lesson } from '@/lib/types'
import { fmtDate, uid } from '@/lib/utils'

export default function TeacherDashboard() {
  const { user } = useAuth()
  const nav = useNavigate()
  const toast = useToast()
  const [lessons, setLessons] = useState<Lesson[]>([])
  const [attempts, setAttempts] = useState<Attempt[]>([])

  useEffect(() => api.watchLessons(setLessons), [])
  useEffect(() => api.watchAttempts(setAttempts), [])

  const mine = useMemo(
    () => lessons.filter((l) => l.teacherId === user?.uid || l.teacherId === 'seed_teacher'),
    [lessons, user],
  )

  const stats = useMemo(() => {
    const ids = new Set(mine.map((l) => l.id))
    const mineAttempts = attempts.filter((a) => ids.has(a.lessonId))
    const students = new Set(mineAttempts.map((a) => a.studentId))
    const totalTraps = mine.reduce((s, l) => s + l.blocks.filter((b) => b.isWrong).length, 0)
    const hit = mineAttempts.reduce((s, a) => s + a.correct, 0)
    const chances = mineAttempts.reduce((s, a) => s + a.correct + a.missed, 0)
    return {
      lessons: mine.length,
      live: mine.filter((l) => l.isLive).length,
      traps: totalTraps,
      students: students.size,
      plays: mineAttempts.length,
      rate: chances ? Math.round((hit / chances) * 100) : 0,
    }
  }, [mine, attempts])

  const createLesson = async () => {
    if (!user) return
    const lesson: Lesson = {
      id: uid('lesson'),
      title: 'Yeni Ders',
      subject: 'Anatomi',
      description: 'Ders açıklamasını buradan düzenle.',
      teacherId: user.uid,
      teacherName: user.name,
      blocks: [],
      isLive: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    await api.saveLesson(lesson)
    nav(`/hoca/ders/${lesson.id}`)
  }

  const toggleLive = async (l: Lesson) => {
    if (!l.isLive && l.blocks.filter((b) => b.isWrong).length === 0) {
      toast('Yayına almadan önce en az bir hatalı blok işaretlemelisin.', 'error')
      return
    }
    await api.saveLesson({ ...l, isLive: !l.isLive })
    toast(l.isLive ? 'Ders yayından kaldırıldı.' : 'Ders yayında! Öğrenciler girebilir.', 'success')
  }

  const remove = async (l: Lesson) => {
    if (!confirm(`"${l.title}" dersi ve tüm sonuçları silinsin mi?`)) return
    await api.deleteLesson(l.id)
    toast('Ders silindi.', 'info')
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="mx-auto max-w-7xl px-5 py-12 sm:px-6"
    >
      <div className="mb-10 flex flex-wrap items-end justify-between gap-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-indigo-300">
            Öğretim üyesi paneli
          </p>
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Merhaba, <span className="title-grad">{user?.name}</span>
          </h1>
        </div>
        <Button3D size="lg" icon="＋" onClick={createLesson}>
          Yeni Ders Oluştur
        </Button3D>
      </div>

      {/* istatistikler */}
      <div className="mb-12 grid grid-cols-2 gap-4 lg:grid-cols-5">
        {[
          { l: 'Ders', v: stats.lessons, c: 'from-indigo-400 to-violet-400' },
          { l: 'Yayında', v: stats.live, c: 'from-emerald-400 to-teal-400' },
          { l: 'Tuzak', v: stats.traps, c: 'from-rose-400 to-orange-400' },
          { l: 'Öğrenci', v: stats.students, c: 'from-cyan-400 to-sky-400' },
          { l: 'Yakalama %', v: `${stats.rate}`, c: 'from-amber-300 to-yellow-400' },
        ].map((s, i) => (
          <motion.div
            key={s.l}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="glass-soft p-5"
          >
            <p className={`bg-gradient-to-br ${s.c} bg-clip-text font-display text-3xl font-bold text-transparent`}>
              {s.v}
            </p>
            <p className="mt-1 text-xs uppercase tracking-wider text-slate-400">{s.l}</p>
          </motion.div>
        ))}
      </div>

      {/* ders listesi */}
      {mine.length === 0 ? (
        <div className="glass grid place-items-center p-16 text-center">
          <p className="text-5xl">📭</p>
          <h3 className="mt-5 font-display text-xl font-semibold">Henüz ders yok</h3>
          <p className="mt-2 max-w-md text-sm text-slate-400">
            İlk dersini oluştur, notunu blok blok gir ve hangi cümlelerin yanlış olduğunu işaretle.
          </p>
          <div className="mt-7">
            <Button3D onClick={createLesson}>İlk Dersini Oluştur</Button3D>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {mine.map((l, i) => {
            const traps = l.blocks.filter((b) => b.isWrong).length
            const plays = attempts.filter((a) => a.lessonId === l.id).length
            return (
              <motion.div
                key={l.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <TiltCard max={8} lift={18} className="h-full">
                  <div className="glass flex h-full flex-col p-6">
                    <div className="mb-4 flex items-start justify-between gap-3">
                      <span className="rounded-lg bg-indigo-500/15 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-indigo-200 ring-1 ring-indigo-400/25">
                        {l.subject || 'Ders'}
                      </span>
                      <span
                        className={
                          l.isLive
                            ? 'flex items-center gap-1.5 rounded-lg bg-emerald-500/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-300 ring-1 ring-emerald-400/30'
                            : 'rounded-lg bg-white/5 px-2.5 py-1 text-[11px] font-semibold text-slate-400 ring-1 ring-white/10'
                        }
                      >
                        {l.isLive && (
                          <span className="relative flex h-1.5 w-1.5">
                            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400" />
                            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
                          </span>
                        )}
                        {l.isLive ? 'YAYINDA' : 'TASLAK'}
                      </span>
                    </div>

                    <h3 className="font-display text-lg font-semibold leading-snug text-white">
                      {l.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-slate-400">{l.description}</p>

                    <div className="my-5 grid grid-cols-3 gap-2 rounded-2xl border border-white/8 bg-black/25 p-3 text-center">
                      {[
                        ['Blok', l.blocks.length],
                        ['Tuzak', traps],
                        ['Oynanma', plays],
                      ].map(([k, v]) => (
                        <div key={k as string}>
                          <p className="font-display text-lg font-bold text-white">{v as number}</p>
                          <p className="text-[10px] uppercase tracking-wider text-slate-500">
                            {k as string}
                          </p>
                        </div>
                      ))}
                    </div>

                    <p className="mb-4 text-[11px] text-slate-500">
                      Güncelleme: {fmtDate(l.updatedAt)}
                    </p>

                    <div className="mt-auto flex flex-wrap gap-2">
                      <Button3D size="sm" onClick={() => nav(`/hoca/ders/${l.id}`)}>
                        Düzenle
                      </Button3D>
                      <Button3D
                        size="sm"
                        tone={l.isLive ? 'ghost' : 'success'}
                        onClick={() => toggleLive(l)}
                      >
                        {l.isLive ? 'Yayını Durdur' : 'Yayına Al'}
                      </Button3D>
                      <Button3D size="sm" tone="ghost" onClick={() => nav(`/hoca/sonuclar/${l.id}`)}>
                        Sonuçlar
                      </Button3D>
                      <button
                        onClick={() => remove(l)}
                        className="ml-auto rounded-xl px-2.5 py-2 text-xs text-slate-500 transition-colors hover:bg-rose-500/10 hover:text-rose-300"
                        title="Dersi sil"
                      >
                        Sil
                      </button>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            )
          })}
        </div>
      )}
    </motion.div>
  )
}
