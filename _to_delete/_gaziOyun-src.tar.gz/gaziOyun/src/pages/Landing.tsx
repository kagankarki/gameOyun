import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import TiltCard from '@/components/TiltCard'
import { useAuth } from '@/context/AuthContext'
import { EASE } from '@/lib/motion'

const fade = (d = 0) => ({
  initial: { opacity: 0, y: 26 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay: d, ease: EASE },
})

const steps = [
  {
    n: '01',
    title: 'Hoca dersi yükler',
    body: 'Ders notu bloklara ayrılır. Hoca hangi cümlelerin kasıtlı olarak yanlış olduğunu ve doğrusunu işaretler.',
    color: 'from-indigo-400 to-violet-400',
    icon: '📚',
  },
  {
    n: '02',
    title: 'Öğrenci derse girer',
    body: 'Yayındaki ders, kart kart karşısına gelir. Anlatım akarken dikkatini vermek zorundadır.',
    color: 'from-cyan-400 to-sky-400',
    icon: '🎧',
  },
  {
    n: '03',
    title: '“Burada Yanlış Var!”',
    body: 'Hatayı gördüğü anda kırmızı butona basar. Doğru yakaladıysa puan, boşa bastıysa ceza alır.',
    color: 'from-rose-400 to-orange-400',
    icon: '🚨',
  },
  {
    n: '04',
    title: 'Sonuç ve sıralama',
    body: 'Ders bitince doğru/kaçan hatalar ve doğrusu gösterilir; puanlar sıralamaya işlenir.',
    color: 'from-amber-300 to-yellow-400',
    icon: '🏆',
  },
]

const stats = [
  { k: 'Anlık', v: 'Geri Bildirim', d: 'Butona bastığın an cevabı öğren' },
  { k: '3D', v: 'Arayüz', d: 'Derinlikli, akıcı, dikkat çeken tasarım' },
  { k: 'Firebase', v: 'Altyapı', d: 'Gerçek zamanlı, çok kullanıcılı' },
]

export default function Landing() {
  const nav = useNavigate()
  const { user, isTeacher } = useAuth()

  return (
    <motion.div exit={{ opacity: 0 }} className="mx-auto max-w-7xl px-5 sm:px-6">
      {/* ───────────── HERO ───────────── */}
      <section className="scene relative grid min-h-[calc(100vh-70px)] place-items-center py-16">
        <div className="w-full text-center">
          <motion.div {...fade(0)} className="mb-7 flex justify-center">
            <span className="inline-flex items-center gap-2.5 rounded-full border border-white/15 bg-white/[0.06] px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-indigo-200 backdrop-blur-md">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              Gazi Üniversitesi × Prof. Dr. Tuncay Peker
            </span>
          </motion.div>

          <motion.h1
            {...fade(0.08)}
            className="font-display text-[clamp(2.6rem,8.5vw,6.4rem)] font-bold leading-[0.95] tracking-tighter"
          >
            <span className="title-grad">HATAYI</span>
            <br />
            <span className="relative inline-block">
              <span className="title-grad">YAKALA</span>
              <motion.span
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.7, duration: 0.7, ease: EASE }}
                className="absolute -bottom-2 left-0 h-1.5 w-full origin-left rounded-full bg-gradient-to-r from-rose-500 via-amber-400 to-cyan-400"
              />
            </span>
          </motion.h1>

          <motion.p
            {...fade(0.18)}
            className="mx-auto mt-9 max-w-2xl text-[15px] leading-relaxed text-slate-300 sm:text-lg"
          >
            Hoca derste bilinçli olarak <span className="text-rose-300 font-semibold">yanlış bilgi</span> verir.
            Sen hatayı fark ettiğin anda butona basarsın. Dinlemek yerine{' '}
            <span className="text-cyan-300 font-semibold">avlanırsın</span>.
          </motion.p>

          <motion.div {...fade(0.28)} className="mt-11 flex flex-wrap items-center justify-center gap-4">
            {user ? (
              <Button3D size="lg" icon="→" onClick={() => nav(isTeacher ? '/hoca' : '/dersler')}>
                {isTeacher ? 'Panelime Git' : 'Derslere Gir'}
              </Button3D>
            ) : (
              <>
                <Button3D size="lg" icon="🎯" onClick={() => nav('/giris')}>
                  Hemen Başla
                </Button3D>
                <Button3D size="lg" tone="ghost" onClick={() => nav('/giris?rol=teacher')}>
                  Hoca Girişi
                </Button3D>
              </>
            )}
          </motion.div>

          {/* Yüzen örnek kart — ürünün özünü gösterir */}
          <motion.div
            initial={{ opacity: 0, y: 70, rotateX: 26 }}
            animate={{ opacity: 1, y: 0, rotateX: 8 }}
            transition={{ delay: 0.45, duration: 1, ease: EASE }}
            className="preserve-3d mx-auto mt-20 max-w-3xl"
          >
            <TiltCard max={7} lift={30}>
              <div className="glass p-7 text-left sm:p-9">
                <div className="mb-5 flex items-center gap-3">
                  <div className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                  <div className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                  <div className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  <span className="ml-2 text-[11px] uppercase tracking-widest text-slate-400">
                    Canlı ders — Anatomi
                  </span>
                </div>

                <p className="text-lg leading-relaxed text-slate-200 sm:text-xl">
                  “Omuz kuşağını oluşturan kemikler{' '}
                  <span className="rounded-md bg-rose-500/20 px-1.5 py-0.5 text-rose-200 ring-1 ring-rose-400/40">
                    clavicula ve sternum
                  </span>
                  ’dur.”
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-4">
                  <div className="relative">
                    <span className="absolute inset-0 rounded-2xl bg-rose-500/40 animate-pulseRing" />
                    <Button3D tone="danger" size="lg" icon="🚨">
                      Burada Yanlış Var!
                    </Button3D>
                  </div>
                  <p className="text-sm text-slate-400">
                    Doğrusu: <span className="text-emerald-300">clavicula ve scapula</span>
                  </p>
                </div>
              </div>
            </TiltCard>
          </motion.div>
        </div>
      </section>

      {/* ───────────── NASIL ÇALIŞIR ───────────── */}
      <section className="py-24">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          className="mb-14 text-center"
        >
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-indigo-300">
            Nasıl çalışır
          </p>
          <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Dört adımda <span className="title-grad">aktif ders</span>
          </h2>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 40, rotateY: -14 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: i * 0.08, duration: 0.6, ease: EASE }}
            >
              <TiltCard max={11} lift={20} className="h-full">
                <div className="glass h-full p-6">
                  <div className="mb-5 flex items-start justify-between">
                    <span className="text-3xl">{s.icon}</span>
                    <span
                      className={`bg-gradient-to-br ${s.color} bg-clip-text font-display text-3xl font-bold text-transparent`}
                    >
                      {s.n}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-white">{s.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-slate-400">{s.body}</p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ───────────── İSTATİSTİK ŞERİDİ ───────────── */}
      <section className="pb-24">
        <div className="grid gap-6 sm:grid-cols-3">
          {stats.map((s, i) => (
            <motion.div
              key={s.v}
              initial={{ opacity: 0, scale: 0.94 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="glass-soft p-6 text-center"
            >
              <p className="font-display text-3xl font-bold text-white">{s.k}</p>
              <p className="mt-1 text-sm font-semibold text-indigo-300">{s.v}</p>
              <p className="mt-2 text-xs text-slate-400">{s.d}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ───────────── CTA ───────────── */}
      <section className="pb-28">
        <TiltCard max={5} lift={22}>
          <div className="glass relative overflow-hidden p-10 text-center sm:p-16">
            <div className="absolute inset-0 grid-floor opacity-40 [mask-image:radial-gradient(ellipse_at_center,black,transparent_72%)]" />
            <div className="relative">
              <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
                Derse hazır mısın?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-slate-300">
                Öğrenciysen sıralamada yerini al, hocaysan ilk dersini beş dakikada hazırla.
              </p>
              <div className="mt-9 flex flex-wrap justify-center gap-4">
                <Button3D size="lg" onClick={() => nav('/giris')}>
                  Öğrenci Olarak Katıl
                </Button3D>
                <Button3D size="lg" tone="gold" onClick={() => nav('/giris?rol=teacher')}>
                  Ders Oluştur
                </Button3D>
              </div>
              <p className="mt-7 text-xs text-slate-500">
                Zaten hesabın var mı?{' '}
                <Link to="/giris" className="text-indigo-300 underline-offset-4 hover:underline">
                  Giriş yap
                </Link>
              </p>
            </div>
          </div>
        </TiltCard>
      </section>
    </motion.div>
  )
}
