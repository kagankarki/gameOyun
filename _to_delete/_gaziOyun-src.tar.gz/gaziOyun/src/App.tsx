import { Suspense, lazy, type ReactNode } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'

import SceneBoundary from './components/SceneBoundary'
import Navbar from './components/Navbar'
import Loader from './components/Loader'
import { useAuth } from './context/AuthContext'

const Landing = lazy(() => import('./pages/Landing'))
const Login = lazy(() => import('./pages/Login'))
const TeacherDashboard = lazy(() => import('./pages/TeacherDashboard'))
const LessonEditor = lazy(() => import('./pages/LessonEditor'))
const LiveResults = lazy(() => import('./pages/LiveResults'))
const StudentLessons = lazy(() => import('./pages/StudentLessons'))
const LessonPlay = lazy(() => import('./pages/LessonPlay'))
const Leaderboard = lazy(() => import('./pages/Leaderboard'))

function Protected({ children, teacher }: { children: ReactNode; teacher?: boolean }) {
  const { user, loading, isTeacher } = useAuth()
  if (loading) return <Loader />
  if (!user) return <Navigate to="/giris" replace />
  if (teacher && !isTeacher) return <Navigate to="/dersler" replace />
  return <>{children}</>
}

export default function App() {
  const location = useLocation()
  const immersive = location.pathname.startsWith('/ders/')

  return (
    <div className="relative flex min-h-screen flex-col">
      <SceneBoundary dim={immersive ? 0.82 : 0.6} />
      <Navbar />

      <main className="flex-1">
        <Suspense fallback={<Loader />}>
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/" element={<Landing />} />
              <Route path="/giris" element={<Login />} />

              <Route
                path="/dersler"
                element={
                  <Protected>
                    <StudentLessons />
                  </Protected>
                }
              />
              <Route
                path="/ders/:id"
                element={
                  <Protected>
                    <LessonPlay />
                  </Protected>
                }
              />
              <Route
                path="/siralama"
                element={
                  <Protected>
                    <Leaderboard />
                  </Protected>
                }
              />

              <Route
                path="/hoca"
                element={
                  <Protected teacher>
                    <TeacherDashboard />
                  </Protected>
                }
              />
              <Route
                path="/hoca/ders/:id"
                element={
                  <Protected teacher>
                    <LessonEditor />
                  </Protected>
                }
              />
              <Route
                path="/hoca/sonuclar/:id"
                element={
                  <Protected teacher>
                    <LiveResults />
                  </Protected>
                }
              />

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </AnimatePresence>
        </Suspense>
      </main>

      <footer className="border-t border-white/10 bg-ink-900/40 py-6 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-6 text-xs text-slate-400 sm:flex-row">
          <p>
            © {new Date().getFullYear()} Gazi Üniversitesi ·{' '}
            <span className="text-indigo-300">Prof. Dr. Tuncay Peker</span> iş birliğiyle
          </p>
          <p className="text-slate-500">Hatayı Yakala · interaktif ders platformu</p>
        </div>
      </footer>
    </div>
  )
}
