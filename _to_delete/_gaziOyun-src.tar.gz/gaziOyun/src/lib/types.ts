export type Role = 'teacher' | 'student'

export interface AppUser {
  uid: string
  name: string
  email: string
  role: Role
  createdAt: number
}

/** Ders notunun tek bir parçası (paragraf / madde / cümle) */
export interface Block {
  id: string
  text: string
  /** Hoca bu bloğa kasıtlı hata koyduysa true */
  isWrong: boolean
  /** Hatanın doğrusu / açıklaması — öğrenci yakalayınca gösterilir */
  correction?: string
  /** Bu bloğun puanı (varsayılan 100) */
  points?: number
}

export interface Lesson {
  id: string
  title: string
  description: string
  subject: string
  teacherId: string
  teacherName: string
  blocks: Block[]
  /** true ise öğrenciler girip oynayabilir */
  isLive: boolean
  createdAt: number
  updatedAt: number
}

export interface Attempt {
  id: string
  lessonId: string
  lessonTitle: string
  studentId: string
  studentName: string
  /** Öğrencinin "burada yanlış var" dediği blok id'leri */
  flagged: string[]
  correct: number
  missed: number
  falseAlarm: number
  score: number
  durationMs: number
  finishedAt: number
}

export interface LeaderRow {
  studentId: string
  studentName: string
  totalScore: number
  attempts: number
  bestScore: number
  accuracy: number
}
