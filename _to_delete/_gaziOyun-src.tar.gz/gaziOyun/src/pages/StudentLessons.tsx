import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import Button3D from '@/components/Button3D'
import TiltCard from '@/components/TiltCard'
import { useAuth } from '@/context/AuthContext'
import * as api from '@/lib/api'
import type { Attempt, Lesson } from '@/lib/types'
import { cx, fmtDate } from '@/lib/utils'

export default function StudentLessons() {
  const nav = useNavigate()
  const { user } = useAuth()
  const [lessons, setLessons] = useState<Lesson[]>([])
  const [attempts, setAttempts] = useState<Attempt[]>([])
  const [q, setQ] = useState('')

  useEffect(() => api.watchLessons(setLessons), [])
  useEffect(() => api.watchAttempts(setAttempts), [])

  const mineAttempts = useMemo(
    () => attempts.filter((a) => a.studentId === user?.uid),
    [attempts, user],
  )

  const liveLessons = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase('tr-TR')
    return lessons
      .filter((l) => l.isLive)
      .filter(
        (l) =>
          !needle ||
          l.title.toLocaleLowerCase('tr-TR').includes(needle) ||
          l.subject?.toLocaleLowerCase('tr-TR').includes(needle) ||
          l.teacherName.toLocaleLowerCase('tr-TR').includes(needle),
      )
  }, [lessons, q])

  const myTotal = mineAttempts.reduce((s, a) => s + a.score, 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="mx-auto max-w-7xl px-5 py-12 sm:px-6"
    >
      <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-indigo-300">
            Yayındaki dersler
          </p>
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Hazır mısın <span className="title-grad">{user?.name?.split(' ')[0]}</span>?
          </h1>
          <p className="mt-3 text-sm text-slate-400">
            Toplam puanın:{' '}
            <span className="font-display text-lg font-bold text-amber-300">{myTotal}</span> ·{' '}
            {mineAttempts.length} ders tamamladın
          </p>
        </div>

        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Ders, konu veya hoca ara…"
          className="w-full max-w-xs rounded-2xl border border-white/12 bg-white/[0.05] px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-all focus:border-indigo-400/60 focus:ring-4 focus:ring-indigo-500/15"
        />
      </div>

      {liveLessons.length === 0 ? (
        <div className="glass grid place-items-center p-16 text-center">
          <p className="text-5xl">🌙</p>
          <h3 className="mt-5 font-display text-xl font-semibold">Şu an yayında ders yok</h3>
          <p className="mt-2 max-w-md text-sm text-slate-400">
            Hoca dersi yayına aldığında burada anında görünecek. Sıralamaya göz atabilirsin.
          </p>
          <div className="mt-7">
            <Button3D tone="ghost" onClick={() => nav('/siralama')}>
              Sıralamayı Gör
            </Button3D>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {liveLessons.map((l, i) => {
            const traps = l.blocks.filter((b) => b.isWrong).length
            const best = mineAttempts
              .filter((a) => a.lessonId === l.id)
              .reduce((m, a) => Math.max(m, a.score), -1)
            return (
              <motion.div
                key={l.id}
                initial={{ opacity: 0, y: 30, rotateX: -8 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ delay: i * 0.06, duration: 0.5 }}
              >
                <TiltCard max={9} lift={20} className="h-full">
                  <div className="glass flex h-full flex-col overflow-hidden p-6">
                    <div className="mb-4 flex items-center justify-between">
                      <span className="rounded-lg bg-indigo-500/15 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-indigo-200 ring-1 ring-indigo-400/25">
                        {l.subject || 'Ders'}
                      </span>
                      <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-300">
                        <span className="relative flex h-1.5 w-1.5">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400" />
                          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
                        </span>
                        CANLI
                      </span>
                    </div>

                    <h3 className="font-display text-lg font-semibold leading-snug text-white">
                      {l.title}
                    </h3>
                    <p className="mt-1 text-xs text-indigo-300/80">{l.teacherName}</p>
                    <p className="mt-3 line-clamp-3 text-sm text-slate-400">{l.description}</p>

                    <div className="my-5 flex flex-wrap gap-2 text-[11px]">
                      <span className="rounded-lg bg-white/6 px-2.5 py-1 text-slate-300">
                        {l.blocks.length} bölüm
                      </span>
                      <span className="rounded-lg bg-rose-500/12 px-2.5 py-1 text-rose-300 ring-1 ring-rose-400/20">
                        {traps} gizli hata
                      </span>
                      {best >= 0 && (
                        <span className="rounded-lg bg-amber-400/12 px-2.5 py-1 text-amber-300 ring-1 ring-amber-400/20">
                          En iyin: {best}
                        </span>
                      )}
                    </div>

                    <p className="mb-4 text-[11px] text-slate-500">{fmtDate(l.updatedAt)}</p>

                    <div className={cx('mt-auto')}>
                      <Button3D full onClick={() => nav(`/ders/${l.id}`)} icon="▶">
                        {best >= 0 ? 'Tekrar Oyna' : 'Derse Gir'}
                      </Button3D>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Geçmiş denemeler */}
      {mineAttempts.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-5 font-display text-2xl font-bold tracking-tight">Son denemelerin</h2>
          <div className="glass divide-y divide-white/8 overflow-hidden">
            {mineAttempts.slice(0, 6).map((a) => {
              const total = a.correct + a.missed
              const pct = total ? Math.round((a.correct / total) * 100) : 0
              return (
                <div key={a.id} className="flex flex-wrap items-center gap-4 px-6 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-white">{a.lessonTitle}</p>
                    <p className="text-[11px] text-slate-500">{fmtDate(a.finishedAt)}</p>
                  </div>
                  <div className="flex items-center gap-5 text-sm">
                    <span className="text-emerald-300">{a.correct} ✓</span>
                    <span className="text-slate-500">{a.missed} kaçtı</span>
                    <span className="text-rose-300">{a.falseAlarm} boş</span>
                    <span className="w-16 text-right font-display font-bold text-amber-300">
                      {a.score}
                    </span>
                    <span className="w-12 text-right text-xs text-slate-400">%{pct}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </section>
      )}
    </motion.div>
  )
}
