/** Projede kullanılan ortak yumuşatma eğrisi (ease-out-expo benzeri). */
export const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1]
